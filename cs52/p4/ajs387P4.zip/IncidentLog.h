/* IncidentLog.h
*  COSC 052 Fall 2016
*  Project #4
*
*  Due on: NOV 17, 2016
*  Author: Andrew Sedlack
*
*
*  In accordance with the class policies and Georgetown's
*  Honor Code, I certify that, with the exception of the
*  class resources and those items noted below, I have neither
*  given nor received any assistance on this project.
*
*  References not otherwise commented within the program source code.
*  Note that you should not mention any help from the TAs, the professor,
*  or any code taken from the class textbooks.*/
#include <iostream>
#include <string>
#include <ctime>
#include <vector>
#include "LL.h"

using std::cout;
using std::cin;
using std::endl;
using std::out_of_range;

//DECLARATION

//has two vector members, one for each report type
class IncidentLog {
    LL<HazMat7k*> allIncidents;

public:
    //sad lil constructor and destructor
    IncidentLog();
    ~IncidentLog();

    //displays all reports in the Log
    void displayReport() const;

    //appending new reports
    void appendObject(HazMat7k* a){allIncidents.push_back(a);}

    //return size of list
    unsigned long size() const {return allIncidents.size();}
};

//IMPLEMENTATION

//constructor and destructor
IncidentLog::IncidentLog() {}
IncidentLog::~IncidentLog() {}

//prints all the reports
void IncidentLog::displayReport() const {
    try{
        double atT, itT;
        //prints each element of the vector.
        cout << endl << "FORM PHMSA F 7000-1 Accident Report - Hazardous Liquid Pipeline Systems ("
             << size() << ") records:" << endl;
        
        ProcessTimer timer1;
        for(int i = 0; i < size(); i++) allIncidents.at(i)->summaryReport();
        atT = timer1.getTimeElapsed();

        LL_iterator<HazMat7k*> i = allIncidents.begin(), stop = allIncidents.end();

        ProcessTimer timer2;
        while(i != stop) {  
          (*i)->summaryReport();
          i++;
        }
        itT = timer2.getTimeElapsed();
        cout << endl << "at(): " << atT << " iterator: " << itT;
    }
    //should something unexpected happen
    catch (out_of_range oorErr) {
        cout << oorErr.what();
        throw;
    }
}

