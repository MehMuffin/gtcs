/*  IncidentLog.h
 *  COSC 052 Fall 2016
 *  Project #1
 * 
 *  Due on: SEP 27, 2016
 *  Author: Andrew Sedlack
 *
 *
 *  In accordance with the class policies and Georgetown's
 *  Honor Code, I certify that, with the exception of the
 *  class resources and those items noted below, I have neither 
 *  given nor received any assistance on this project.*/
#include <iostream>
#include <string>
#include <vector> 
#include "PHMSA7000.h"

using std::cout;
using std::endl;

class IncidentLog {
    std::vector<HazMat7k> allIncidents;

public:
    IncidentLog();
    ~IncidentLog();

    void displayReport() const;
    void appendObject(const HazMat7k&);
    unsigned long size() const;
};
