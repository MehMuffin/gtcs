/*  IncidentLog.cpp
 *  COSC 052 Fall 2016
 *  Project #1
 * 
 *  Due on: SEP 27, 2016
 *  Author: Andrew Sedlack
 *
 *
 *  In accordance with the class policies and Georgetown's
 *  Honor Code, I certify that, with the exception of the
 *  class resources and those items noted below, I have neither 
 *  given nor received any assistance on this project.*/
#include <iostream>
#include <string>
#include <vector>
#include "IncidentLog.h"

using std::cout;

//constructor and destructor
IncidentLog::IncidentLog() {} 
IncidentLog::~IncidentLog() {}

//prints all the reports
void IncidentLog::displayReport() const {
    cout << endl << "FORM PHMSA F 7000-1 Accident Report - Hazardous Liquid Pipeline Systems ("
         << allIncidents.size() << ") records:" << endl;
    
    for(int i = 0; i < allIncidents.size(); i++) allIncidents[i].summaryReport();

    //prints each element of the vector
    //for(HazMat7k i : allIncidents) i.summaryReport();
}

//adds a new object to the vector
void IncidentLog::appendObject(const HazMat7k &a) {allIncidents.push_back(a);}

//returns the size of the vector
unsigned long IncidentLog::size() const {return allIncidents.size();}
