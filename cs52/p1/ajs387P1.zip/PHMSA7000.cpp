/*  PHMSA7000.cpp
 *  COSC 052 Fall 2016
 *  Project #1
 * 
 *  Due on: SEP 27, 2016
 *  Author: Andrew Sedlack
 *
 *
 *  In accordance with the class policies and Georgetown's
 *  Honor Code, I certify that, with the exception of the
 *  class resources and those items noted below, I have neither 
 *  given nor received any assistance on this project.*/
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <fstream>
#include "PHMSA7000.h"

using std::ostream;
using std::string; 
using std::cout;
using std::endl;

HazMat7k::~HazMat7k() {}

//tragically ugly and useless default constructor
HazMat7k::HazMat7k(Date report_received_date, string report_number, string supplemental_number,
    string report_type, string operator_id, string name_, string operator_street_address,
    string operator_city_name, string operator_state_abbreviation, string operator_postal_code,
    Date local_date, Time local_time, string commodity_released_type,
    double unintentional_release_bbls, double intentional_release_bbls, double recovered_bbls,
    int fatalities, int injured, string ignite_ind, string explode_ind, Date prepared_date,
    string authorizer_name, string authorizer_email, string narrative_) :
    //and now the initialization list
    reportReceivedDate(report_received_date),
    reportNumber(report_number),
    supplementalNumber(supplemental_number),
    reportType(report_type),
    operatorID(operator_id),
    name(name_),
    operatorStreetAddress(operator_street_address),
    operatorCityName(operator_city_name),
    operatorStateAbbreviation(operator_state_abbreviation),
    operatorPostalCode(operator_postal_code),
    localDate(local_date),
    localTime(local_time),
    commodityReleasedType(commodity_released_type),
    unintentionalReleaseBbls(unintentional_release_bbls),
    intentionalReleaseBbls(intentional_release_bbls),
    recoveredBbls(recovered_bbls),
    fatal(fatalities),
    injure(injured),
    igniteInd(ignite_ind),
    explodeInd(explode_ind),
    preparedDate(prepared_date),
    authorizerName(authorizer_name),
    authorizerEmail(authorizer_email),
    narrative(narrative_)
{}

HazMat7k::HazMat7k(const HazMatData &d) :
    reportReceivedDate(d.report_received_date),
    reportNumber(d.report_number),
    supplementalNumber(d.supplemental_number),
    reportType(d.report_type),
    operatorID(d.operator_id),
    name(d.name),
    operatorStreetAddress(d.operator_street_address),
    operatorCityName(d.operator_city_name),
    operatorStateAbbreviation(d.operator_state_abbreviation),
    operatorPostalCode(d.operator_postal_code),
    localDate(d.local_date),
    localTime(d.local_time),
    commodityReleasedType(d.commodity_released_type),
    unintentionalReleaseBbls(d.unintentional_release_bbls),
    intentionalReleaseBbls(d.intentional_release_bbls),
    recoveredBbls(d.recovered_bbls),
    fatal(d.fatal),
    injure(d.injure),
    igniteInd(d.ignite_ind),
    explodeInd(d.explode_ind),
    preparedDate(d.prepared_date),
    authorizerName(d.authorizer_name),
    authorizerEmail(d.authorizer_email),
    narrative(d.narrative)
{}

void HazMat7k::summaryReport() const { 
    cout << "Report Number and Date:        " << reportNumber + "  " << reportReceivedDate << endl
        << "Local Date and Time:           " << localDate << "  " << localTime << endl
        << "Number of Injuries:       " << injure << endl
        << "Number of Fatalities:     " << fatal << endl
        << "Narrative Length: " << narrative.length() << endl
        << "Narrative: " << narrative << endl << endl << endl;
}

std::ostream& operator<<(std::ostream& out, const HazMat7k &rhs){
    out << "Report Number and Date: " << rhs.reportNumber + ' ' 
        << rhs.reportReceivedDate << "   "
        << "Local Date and Time: " << rhs.localDate << ' ' 
        << rhs.localTime << "   "
        << "Number of Injuries: " << rhs.injure << "   "
        << "Number of Fatalities: " << rhs.fatal << "   "
        << "Narrative Length: " << rhs.narrative.length() << "   "
        << "Narrative: " << rhs.narrative;
}
