/*  ajs387P1.cpp
 *  COSC 052 Fall 2016
 *  Project #1
 * 
 *  Due on: SEP 27, 2016
 *  Author: Andrew Sedlack
 *
 *
 *  In accordance with the class policies and Georgetown's
 *  Honor Code, I certify that, with the exception of the
 *  class resources and those items noted below, I have neither 
 *  given nor received any assistance on this project.*/


#include <fstream>
#include "IncidentLog.h"
#define ENTRY_SIZE 4472 //size of a full struct.

using namespace std;

void loadData (string path, string type, IncidentLog &l){
    //a struct to load into
    HazMatData* raw = new HazMatData;
    
    //open the file, starting at the end in order to find the size
    fstream file(path.c_str(), ios::in | ios::binary);
    
    //Use of seekg from cppreference.com
    file.seekg(0, ios::end);//set pointer to end
    int size = file.tellg();//in order to find file size
    file.seekg(0, ios::beg);//and then reset back to beginning
    
    do {
        file.read(reinterpret_cast<char *>(raw), ENTRY_SIZE);
        
        HazMat7k data(*raw); //convert each loaded report into an object and append it
        l.appendObject(data);
    
    } while(file.tellg() < size); //loop until the pointer reaches the end of the file.
    
    file.close(); //cleaning up
    delete[] raw;
}

int main (int argc, char* argv[]){
    IncidentLog l;

    //if the type is not binary, don't try to load
    if((char)(*argv[2])!='b') cout << "Invalid File Type.";
    else {
        loadData(argv[1], argv[2], l);
        l.displayReport(); //print the final log (or nothing, if nothing's been loaded)
    }
    return 0;
}
