/*  IncidentLog.cpp
 *  COSC 052 Fall 2016
 *  Project #2
 * 
 *  Due on: OCT 13, 2016
 *  Author: Andrew Sedlack
 *
 *
 *  In accordance with the class policies and Georgetown's
 *  Honor Code, I certify that, with the exception of the
 *  class resources and those items noted below, I have neither 
 *  given nor received any assistance on this project.*/
#include <iostream>
#include <stdexcept>
#include <exception>
#include <string>
#include <vector>
#include "IncidentLog.h"

using std::cout;
using std::out_of_range;

//constructor and destructor.
IncidentLog::IncidentLog() {} 
IncidentLog::~IncidentLog() {}

//prints all the reports.
void IncidentLog::displayReport() const {
    try{
        //prints each element of the vector.
        cout << endl << "FORM PHMSA F 7000-1 Accident Report - Hazardous Liquid Pipeline Systems ("
             << sizeFatalityOrInjury() << ") records with a fatality or injury:" << endl;

        for(int i = 0; i < sizeFatalityOrInjury(); i++) vFatalityOrInjury.at(i).summaryReport();
        
        cout << endl << "FORM PHMSA F 7000-1 Accident Report - Hazardous Liquid Pipeline Systems ("
             << sizeLossOrDamage() << ") records with only material loss or damage:" << endl;

        for(int i = 0; i < sizeLossOrDamage(); i++) vLossOrDamage.at(i).summaryReport();

    }
    //should something unexpected happen.
    catch (out_of_range oorErr) {
        cout << oorErr.what();
        throw;
    }
}

//adds a new object to each vector, as appropriate.
void IncidentLog::appendObject(const LossOrDamage &a) {vLossOrDamage.push_back(a);}
void IncidentLog::appendObject(const FatalityOrInjury &a) {vFatalityOrInjury.push_back(a);}
//returns the size of each vector.
unsigned long IncidentLog::sizeLossOrDamage() const {return vLossOrDamage.size();}
unsigned long IncidentLog::sizeFatalityOrInjury() const {return vFatalityOrInjury.size();}
